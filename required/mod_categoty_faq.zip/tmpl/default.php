<?php
defined( '_JEXEC' ) or die;


?>

<div class="category-faq col-md-12 no-gutter <?php echo $moduleclass_sfx; ?>">
	<h3><?php echo $params->get('name'); ?></h3>
	<div class="col-xs-12 col-sm-12 col-md-4">
		<?php
			$active = false;
			for($i = 0; $i < 10; $i++) {
				$label = $params->get('label' . $i);
				$info = $params->get('info' . $i);
				
				if (isset($label) && isset($info)) { ?>
					<p><a href="#" class="<?php echo 'tab-' . $i; if (!$active) { $active = true; ?> active <?php
					} ?>">
					<?php echo $label; ?></a></p><?php
				}
			} ?>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-8 category-faq-info">
		<?php
			$active = false;
			for($i = 0; $i < 10; $i++) {
				$label = $params->get('label' . $i);
				$info = $params->get('info' . $i);
				
				if (isset($label) && isset($info)) {?>
				
					<div class="info-<?php echo 'tab-' . $i; if (!$active) { $active = true; ?> active<?php
					} ?>">
					<?php echo $info; ?>
					</div><?php
				} ?>
			<?php
			} ?>
	</div>
</div>