<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 * Class Module Helper
 * @author 
 */
class modCarouselHelper
{

	/**
	 * getData method
	 * @param $params
	 * @return array
	 */
	static function getData( $params )
	{
		$db = JFactory::getDbo();
		return array();
	}

}