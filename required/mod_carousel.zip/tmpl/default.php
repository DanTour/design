<?php
// No direct access
defined( '_JEXEC' ) or die;
?>

<div id="myCarousel" class="carousel slide <?php echo $moduleclass_sfx; ?>" data-ride="carousel">
	<ol class="carousel-indicators">
		<?php
			$active = false;
			
			for ($i = 0; $i < 10; $i++) {
				$title = $params->get('title' . $i);
				$text = $params->get('text' . $i);
				
				if (isset($title) && isset($text)) { ?>
					<li data-target="#myCarousel" data-slide-to="
					<?php echo $i; ?>
					" class="
					<?php if (!$active) {
						$active = true; ?>
						active
					<?php
						}
					?>"></li>
		<?php	}
			}
		?>
	</ol>
	<div class="carousel-inner" role="listbox">
		<?php
		$active = false;
			
		for ($i = 0; $i < 10; $i++) {
			$title = $params->get('title' . $i);
			$text = $params->get('text' . $i);
			$image = $params->get('image' . $i); 
			
			if (isset($title) && isset($text)) {
			?>
		
			<div class="item <?php
				if (!$active) {
					$active = true; ?>
					active
					<?php
				}
			?>" style="background-image:url(<?php echo $image; ?>);">
				<div class="container">
					<div class="carousel-caption">
						<h1><?php echo $title; ?></h1>
						<p><?php echo $text; ?>
					</div>
				</div>
			</div>
		
		<?php }
		} ?>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<p class="glyphicon glyphicon-chevron-left" aria-hidden="true"></p>
			<p class="sr-only">Previous</p>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<p class="glyphicon glyphicon-chevron-right" aria-hidden="true"></p>
			<p class="sr-only">Next</p>
		</a>
	</div>
</div>