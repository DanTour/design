<?php
// No direct access
defined( '_JEXEC' ) or die;
?>

<div id="myCarousel" class="carousel slide <?php echo $moduleclass_sfx; ?>" data-ride="carousel">
	<ol class="carousel-indicators">
		<?php
			$active = false;
			
			for ($i = 0; $i < 10; $i++) {
				$title = $params->get('title' . $i);
				$text = $params->get('text' . $i);
				
				if (isset($text)) { ?>
					<li data-target="#myCarousel" data-slide-to="
					<?php echo $i; ?>
					" class="
					<?php if (!$active) {
						$active = true; ?>
						active
					<?php
						}
					?>"></li>
		<?php	}
			}
		?>
	</ol>
	<div class="carousel-inner" role="listbox">
		<?php
		$active = false;
			
		for ($i = 0; $i < 10; $i++) {
			$title = $params->get('title' . $i);
			$text = $params->get('text' . $i);
			$image = $params->get('image' . $i); 
			
			if (isset($text)) {
			?>
		
			<div class="item <?php
				if (!$active) {
					$active = true; ?>
					active
					<?php
				}
			?>" style="background-image:url(<?php echo $image; ?>);">
			<?php if ($params->get('carouselType') == 1 )	: ?>
				<div class="carousel-caption">
					<div class="row">	
						<h1 class="col-md-10 col-md-offset-1"><?php echo $title; ?></h1>
					</div>
					<div class="row">	
						<?php echo $text; ?>
					</div>
				</div>
			</div>
			<?php else :  ?>
			<div class="container">
				<div class="carousel-list col-md-4 col-md-offset-8 no-gutter col-xs-8 col-xs-offset-2 ">
						<h5><?php echo $title ?></h5>
						<div class="description">
							<?php echo $text ; ?>
						</div>
				</div>
				</div>
			</div>
			<?php endif ?> 
		<?php }
		} ?>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<p class="glyphicon glyphicon-chevron-left" aria-hidden="true"></p>
			<p class="sr-only">Previous</p>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<p class="glyphicon glyphicon-chevron-right" aria-hidden="true"></p>
			<p class="sr-only">Next</p>
		</a>
	</div>
</div>